package es.uca.aspectos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AspectosApplicationTests {

	@Test
	void contextLoads() {
	}

}
