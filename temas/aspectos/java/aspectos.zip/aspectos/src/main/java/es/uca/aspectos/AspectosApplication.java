package es.uca.aspectos;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AspectosApplication {

	public static void main(String[] args) {
		SpringApplication.run(AspectosApplication.class, args);
	}

}
